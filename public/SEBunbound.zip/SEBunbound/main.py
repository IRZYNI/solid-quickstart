import pyperclip as clip
import time
import wmi
import json
import google.generativeai as genai
import random
import os
import difflib
import uuid
import hashlib
from datetime import datetime, timedelta
from cryptography.fernet import Fernet

# ASCII Banner
def show_banner():
    print(r"""
                                                                         .-'''-.                                   
                                                                        '   _    \                   _______       
                __.....__     /|                     _..._   /|       /   /` '.   \          _..._   \  ___ `'.    
            .-''         '.   ||                   .'     '. ||      .   |     \  '        .'     '.  ' |--.\  \   
           /     .-''"'-.  `. ||                  .   .-.   .||      |   '      |  '      .   .-.   . | |    \  '  
          /     /________\   \||  __              |  '   '  |||  __  \    \     / /       |  '   '  | | |     |  ' 
       _  |                  |||/'__ '.   _    _  |  |   |  |||/'__ '.`.   ` ..' /_    _  |  |   |  | | |     |  | 
     .' | \    .-------------'|:/`  '. ' | '  / | |  |   |  ||:/`  '. '  '-...-'`| '  / | |  |   |  | | |     ' .' 
    .   | /\    '-.____...---.||     | |.' | .' | |  |   |  |||     | |         .' | .' | |  |   |  | | |___.' /'  
  .'.'| |// `.             .' ||\    / '/  | /  | |  |   |  |||\    / '         /  | /  | |  |   |  |/_______.'/   
.'.'.-'  /    `''-...... -'   |/\'..' /|   `'.  | |  |   |  ||/\'..' /         |   `'.  | |  |   |  |\_______|/    
.'   \_.'                     '  `'-'` '   .'|  '/|  |   |  |'  `'-'`          '   .'|  '/|  |   |  |              
                                        `-'  `--' '--'   '--'                   `-'  `--' '--'   '--'  
 """)
    print("SEB Assistant - Operational\n")


LICENSE_DIR = os.path.join(os.environ.get('APPDATA'), 'SEB_Assistant_License')
LICENSE_FILE = os.path.join(LICENSE_DIR, "license.key")
ENCRYPTION_KEY_FILE = os.path.join(LICENSE_DIR, "encryption.key")
TRIAL_FILE = os.path.join(LICENSE_DIR, "trial.dat")
CONFIG_FILE = "seb_config.json"
SELF_IDENTIFIER = "12SEB_ANSWER21"
QA_FOLDER = "Answer-Key"
HYBRID_COMMAND = "h-switch"

if not os.path.exists(LICENSE_DIR):
    os.makedirs(LICENSE_DIR)

def get_encryption_key():
    master_key = b'pSRe8vnRc8RF2z_simjFwJhnQcdZqlDBDGio2sG04P0='  
    
    if not os.path.exists(ENCRYPTION_KEY_FILE):
        with open(ENCRYPTION_KEY_FILE, "wb") as f:
            f.write(master_key)
    
    return master_key

# Global encryption key
FERNET_KEY = get_encryption_key()

def generate_hardware_fingerprint():
    c = wmi.WMI()
    identifiers = []
    
    # MAC Address
    identifiers.append(hex(uuid.getnode()))
    
    # Disk Serial
    try:
        for disk in c.Win32_DiskDrive():
            if disk.SerialNumber:
                serial = disk.SerialNumber.strip()
                if serial: identifiers.append(serial)
    except Exception:
        pass
    
    # Motherboard Serial
    try:
        for board in c.Win32_BaseBoard():
            if board.SerialNumber:
                serial = board.SerialNumber.strip()
                if serial: identifiers.append(serial)
    except Exception:
        pass
    
    # CPU ID
    try:
        for proc in c.Win32_Processor():
            if proc.ProcessorId:
                cpu_id = proc.ProcessorId.strip()
                if cpu_id: identifiers.append(cpu_id)
    except Exception:
        pass
    
    # Join all identifiers and hash them
    fingerprint_str = ''.join([str(i) for i in identifiers])
    return hashlib.sha256(fingerprint_str.encode()).hexdigest()

def safe_clip_paste():
    try:
        return clip.paste().strip()
    except Exception as e:
        print(f"Clipboard error: {str(e)}")
        return ""

def load_config():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f"Config error: {str(e)}")
    return {"gemini_key": "", "last_mode": 1}

def save_config(config):
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f)
    except Exception as e:
        print(f"Save config failed: {str(e)}")

def get_power_status():
    try:
        batteries = wmi.WMI().Win32_Battery()
        if batteries:
            return batteries[0].BatteryStatus == 1
        return False
    except Exception as e:
        print(f"Power check failed: {str(e)}")
        return False

def ai_operations(api_key):
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-1.5-pro')
        print("\nAI connection established")
        last_query = ""
        
        while True:
            try:
                if get_power_status():
                    query = safe_clip_paste().strip()
                    
                    # Check for hybrid command
                    if query == HYBRID_COMMAND:
                        print("\n[SYSTEM] Switching to JSON mode...")
                        clip.copy("")
                        return "switch"
                    
                    if query and SELF_IDENTIFIER not in query and query != last_query:
                        # Generate AI response
                        response = model.generate_content(query)
                        
                        if response and response.text:
                            answer = f"{response.text}\n{SELF_IDENTIFIER}"
                            clip.copy(answer)
                            print("\nAI Response Generated:")
                            print(f"Question: {query[:75]}")
                            print(f"Answer: {response.text[:150]}...")
                            last_query = answer
                        else:
                            print("\nEmpty response from AI")
                            clip.copy("ERROR: No response generated")
                        
                time.sleep(4 + random.uniform(1, 2))
                
            except Exception as e:
                print(f"AI Error: {str(e)}")
                clip.copy("ERROR: AI service unavailable")
                time.sleep(10)

    except Exception as e:
        print(f"AI Setup Failed: {str(e)}")
        return "error"

def json_operations(module_name):
    try:
        # Create Answer-Key directory if it doesn't exist
        if not os.path.exists(QA_FOLDER):
            os.makedirs(QA_FOLDER)
            print(f"Created {QA_FOLDER} directory")
            
        file_path = f"{QA_FOLDER}/{module_name}.json"
        if not os.path.exists(file_path):
            print(f"Warning: {file_path} not found")
            return
            
        with open(file_path) as f:
            qa_data = json.load(f)
            
        print(f"\nLoaded {len(qa_data)} Q/A pairs from {module_name}")
        last_query = ""
        
        while True:
            try:
                if get_power_status():
                    query = safe_clip_paste().strip()
                    
                    # Hybrid mode switching
                    if query == HYBRID_COMMAND:
                        print("\n[SYSTEM] Switching to AI mode...")
                        clip.copy("")
                        return "switch"
                    
                    if query and SELF_IDENTIFIER not in query and query != last_query:
                        # Fuzzy matching implementation
                        matches = difflib.get_close_matches(
                            query, 
                            qa_data.keys(),
                            n=1,
                            cutoff=0.7
                        )
                        
                        if matches:
                            best_match = matches[0]
                            answer = qa_data[best_match]
                            similarity = difflib.SequenceMatcher(None, query, best_match).ratio()
                            
                            clip.copy(f"{answer}\n{SELF_IDENTIFIER}")
                            print(f"\nMatch found ({similarity:.0%} confidence)")
                            print(f"Original: {query[:75]}")
                            print(f"Matched: {best_match[:75]}")
                            last_query = answer
                        else:
                            print(f"\nNo match found for: {query[:75]}")
                            
                time.sleep(3 + random.uniform(0.5, 1.5))
                
            except Exception as e:
                print(f"Error: {str(e)}")
                time.sleep(5)

    except Exception as e:
        print(f"Failed to load module: {str(e)}")
        return

def check_trial():
    # If license exists, don't bother with trial
    if os.path.exists(LICENSE_FILE):
        return True
        
    # Get hardware fingerprint
    machine_id = generate_hardware_fingerprint()
    
    # If trial file doesn't exist, create it
    if not os.path.exists(TRIAL_FILE):
        trial_data = {
            'start_date': datetime.now().isoformat(),
            'machine_id': machine_id,
            'uses': 1
        }
        
        cipher = Fernet(FERNET_KEY)
        encrypted = cipher.encrypt(json.dumps(trial_data).encode())
        
        with open(TRIAL_FILE, 'wb') as f:
            f.write(encrypted)
        
        print("\n[SYSTEM] Trial mode activated (7 days or 5 uses)")
        return True
    
    # Read and decrypt trial data
    try:
        cipher = Fernet(FERNET_KEY)
        with open(TRIAL_FILE, 'rb') as f:
            encrypted = f.read()
            
        decrypted = cipher.decrypt(encrypted)
        trial_data = json.loads(decrypted.decode('utf-8'))
        
        # Verify machine ID
        if trial_data['machine_id'] != machine_id:
            print("\n[SYSTEM] Trial validation failed - hardware mismatch")
            return False
        
        # Check start date
        start_date = datetime.fromisoformat(trial_data['start_date'])
        days_passed = (datetime.now() - start_date).days
        
        # Increment use counter
        trial_data['uses'] += 1
        
        # Check if trial expired (7 days or 5 uses)
        if days_passed > 7 or trial_data['uses'] > 5:
            print("\n[SYSTEM] Trial period expired!")
            days_used = min(days_passed, 7)
            print(f"Used {days_used} days out of 7")
            print(f"Used {trial_data['uses']} launches out of 5")
            return False
        
        # Update trial file with incremented use counter
        encrypted = cipher.encrypt(json.dumps(trial_data).encode())
        with open(TRIAL_FILE, 'wb') as f:
            f.write(encrypted)
            
        print(f"\n[SYSTEM] Trial mode: {7-days_passed} days and {5-trial_data['uses']} uses remaining")
        return True
        
    except Exception as e:
        print(f"\n[SYSTEM] Trial validation error: {str(e)}")
        return False
def validate_license():
    if not os.path.exists(LICENSE_FILE):
        print("\n[LICENSE] No license file found")
        return False
    
    try:
        # Get current machine fingerprint
        machine_id = generate_hardware_fingerprint()
        
        # Decrypt and validate license
        cipher = Fernet(FERNET_KEY)
        with open(LICENSE_FILE, 'rb') as f:
            encrypted = f.read()
        
        decrypted = cipher.decrypt(encrypted)
        license_data = json.loads(decrypted.decode('utf-8'))
        
        # Check machine ID
        if license_data['machine_id'] != machine_id:
            print("\n[LICENSE ERROR] This license is not valid for this computer")
            return False
            
        # Get current time for comparison
        current_time = datetime.now().timestamp()
        expiry_time = license_data['expiry']
        
        # Calculate time difference in seconds
        time_remaining_seconds = expiry_time - current_time
        
        # Calculate days precisely
        time_delta = datetime.fromtimestamp(expiry_time) - datetime.now()
        days_left = time_delta.days
        hours_left = time_delta.seconds // 3600
        
        # STRICT CHECK: If less than 1 hour remains or time has expired, reject the license
        if time_remaining_seconds <= 3600:  # 3600 seconds = 1 hour
            expiry_date = datetime.fromtimestamp(expiry_time)
            print(f"\n[LICENSE ERROR] License expired or about to expire on {expiry_date.strftime('%Y-%m-%d %H:%M')}")
            # Delete the license file if it's expired (optional)
            # if time_remaining_seconds <= 0:
            #     os.remove(LICENSE_FILE)
            #     print("[LICENSE] Expired license file removed")
            return False
            
        # Valid license with more than 1 hour remaining
        if days_left > 0:
            print(f"\n[LICENSE] Valid license detected ({days_left} days and {hours_left} hours remaining)")
        else:
            print(f"\n[LICENSE] Valid license detected ({hours_left} hours remaining)")
            
        print(f"License ID: {license_data['license_id']}")
        return True
        
    except Exception as e:
        print(f"\n[LICENSE ERROR] {str(e)}")
        return False
def export_machine_id():
    machine_id = generate_hardware_fingerprint()
    
    print("\n======== SEB Assistant - Machine ID ========")
    print(f"Your Machine ID is: {machine_id}")
    print("\nSend this ID to the software provider to get a license key.")
    print("=========================================\n")
    
    # Save to file for convenience
    with open("machine_id.txt", "w") as f:
        f.write(machine_id)
    
    print("The ID has also been saved to 'machine_id.txt' in this directory.")
    input("\nPress Enter to continue...")

def install_license():
    if not os.path.exists("license_key.txt"):
        print("\n[ERROR] No license key file found.")
        print("Please place your license key file in this directory with the name 'license_key.txt'")
        input("\nPress Enter to continue...")
        return False
        
    try:
        # Read the license file provided by seller
        with open("license_key.txt", "rb") as f:
            license_data = f.read()
            
        # Save it as the license file
        with open(LICENSE_FILE, "wb") as f:
            f.write(license_data)
            
        print("\n[SUCCESS] License installed successfully!")
        input("\nPress Enter to continue...")
        return True
        
    except Exception as e:
        print(f"\n[ERROR] Failed to install license: {str(e)}")
        input("\nPress Enter to continue...")
        return False

def main_interface():
    show_banner()
    config = load_config()
    
    # First check for valid license or trial
    license_valid = validate_license()
    
    if not license_valid:
        # If no valid license, check if trial is valid
        if not check_trial():
            # Show license menu if no valid license or trial
            while True:
                print("\n===== License Management =====")
                print("[1] Export Machine ID (for purchase)")
                print("[2] Install License")
                print("[3] Exit")
                
                choice = input("\nChoice: ").strip()
                
                if choice == "1":
                    export_machine_id()
                elif choice == "2":
                    if install_license():
                        # If license installed successfully, break out of license menu
                        license_valid = True
                        break
                elif choice == "3":
                    return
    
    # Continue with main program if license or trial is valid
    if license_valid or check_trial():
        current_mode = None
        json_module = None
        last_license_check_time = datetime.now()
        
        while True:
            try:
                # Periodic license check (every 15 minutes)
                if license_valid:
                    time_since_check = (datetime.now() - last_license_check_time).total_seconds()
                    if time_since_check > 900:  # 15 minutes in seconds
                        if not validate_license():
                            print("\n[LICENSE] Your license has expired during this session")
                            input("Press Enter to exit...")
                            return
                        last_license_check_time = datetime.now()
                
                if not current_mode:
                    print("\n[1] Json file (locally)\n[2] Gemini AI\n[3] Exit")
                    choice = input("Choose mode: ").strip()
                    
                    if choice == "1":
                        # Create Answer-Key directory if it doesn't exist
                        if not os.path.exists(QA_FOLDER):
                            os.makedirs(QA_FOLDER)
                            print(f"\nCreated {QA_FOLDER} directory")
                        
                        # List available JSON files
                        json_files = [f[:-5] for f in os.listdir(QA_FOLDER) if f.endswith(".json")]
                        
                        if json_files:
                            print("\nAvailable modules:")
                            print("\n".join(json_files))
                            json_module = input("Module name: ").strip()
                            current_mode = "json"
                        else:
                            print(f"\nNo JSON files found in {QA_FOLDER} directory.")
                            print("Please add JSON files to this directory.")
                    elif choice == "2":
                        if not config["gemini_key"]:
                            config["gemini_key"] = input("Gemini API key: ").strip()
                            save_config(config)
                        current_mode = "ai"
                    elif choice == "3":
                        break
                    else:
                        print("Invalid choice")
                else:
                    if current_mode == "json":
                        result = json_operations(json_module)
                        if result == "switch":
                            current_mode = "ai"
                    elif current_mode == "ai":
                        result = ai_operations(config["gemini_key"])
                        if result == "switch":
                            current_mode = "json"
                            
            except KeyboardInterrupt:
                print("\nOperation cancelled")
                break
            except Exception as e:
                print(f"Critical error: {str(e)}")
                time.sleep(2)

if __name__ == "__main__":
    main_interface()